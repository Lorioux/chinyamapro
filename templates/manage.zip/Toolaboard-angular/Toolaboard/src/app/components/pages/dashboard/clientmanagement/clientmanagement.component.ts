import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clientmanagement',
  templateUrl: './clientmanagement.component.html',
  styleUrls: ['./clientmanagement.component.css']
})
export class ClientmanagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
