import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formelements',
  templateUrl: './formelements.component.html',
  styleUrls: ['./formelements.component.css']
})
export class FormelementsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
