import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultregister',
  templateUrl: './defaultregister.component.html',
  styleUrls: ['./defaultregister.component.css']
})
export class DefaultregisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
