import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addengineer',
  templateUrl: './addengineer.component.html',
  styleUrls: ['./addengineer.component.css']
})
export class AddengineerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
