import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-googlecharts',
  templateUrl: './googlecharts.component.html',
  styleUrls: ['./googlecharts.component.css']
})
export class GooglechartsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
