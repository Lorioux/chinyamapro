import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnotice',
  templateUrl: './addnotice.component.html',
  styleUrls: ['./addnotice.component.css']
})
export class AddnoticeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
