import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultlogin',
  templateUrl: './defaultlogin.component.html',
  styleUrls: ['./defaultlogin.component.css']
})
export class DefaultloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
