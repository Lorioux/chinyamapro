import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vectormaps',
  templateUrl: './vectormaps.component.html',
  styleUrls: ['./vectormaps.component.css']
})
export class VectormapsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
