import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sweetalerts',
  templateUrl: './sweetalerts.component.html',
  styleUrls: ['./sweetalerts.component.css']
})
export class SweetalertsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
