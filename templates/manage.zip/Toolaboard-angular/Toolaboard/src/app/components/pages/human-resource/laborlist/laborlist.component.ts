import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-laborlist',
  templateUrl: './laborlist.component.html',
  styleUrls: ['./laborlist.component.css']
})
export class LaborlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
