import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noticelist',
  templateUrl: './noticelist.component.html',
  styleUrls: ['./noticelist.component.css']
})
export class NoticelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
