import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flaticons',
  templateUrl: './flaticons.component.html',
  styleUrls: ['./flaticons.component.css']
})
export class FlaticonsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
