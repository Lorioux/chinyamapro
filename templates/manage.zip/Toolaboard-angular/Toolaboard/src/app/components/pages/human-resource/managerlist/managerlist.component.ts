import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managerlist',
  templateUrl: './managerlist.component.html',
  styleUrls: ['./managerlist.component.css']
})
export class ManagerlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
