import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentlist',
  templateUrl: './paymentlist.component.html',
  styleUrls: ['./paymentlist.component.css']
})
export class PaymentlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
