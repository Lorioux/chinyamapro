import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-representativelist',
  templateUrl: './representativelist.component.html',
  styleUrls: ['./representativelist.component.css']
})
export class RepresentativelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
