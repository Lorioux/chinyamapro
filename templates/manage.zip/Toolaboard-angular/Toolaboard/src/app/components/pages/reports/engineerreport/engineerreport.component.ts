import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engineerreport',
  templateUrl: './engineerreport.component.html',
  styleUrls: ['./engineerreport.component.css']
})
export class EngineerreportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
