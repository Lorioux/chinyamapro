import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addrepresentative',
  templateUrl: './addrepresentative.component.html',
  styleUrls: ['./addrepresentative.component.css']
})
export class AddrepresentativeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
