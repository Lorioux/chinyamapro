import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addmanager',
  templateUrl: './addmanager.component.html',
  styleUrls: ['./addmanager.component.css']
})
export class AddmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
