import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-materialize',
  templateUrl: './materialize.component.html',
  styleUrls: ['./materialize.component.css']
})
export class MaterializeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
