import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projectmanagement',
  templateUrl: './projectmanagement.component.html',
  styleUrls: ['./projectmanagement.component.css']
})
export class ProjectmanagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
