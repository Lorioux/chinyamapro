import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentinvoice',
  templateUrl: './paymentinvoice.component.html',
  styleUrls: ['./paymentinvoice.component.css']
})
export class PaymentinvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
