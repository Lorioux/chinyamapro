import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formwizard',
  templateUrl: './formwizard.component.html',
  styleUrls: ['./formwizard.component.css']
})
export class FormwizardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
