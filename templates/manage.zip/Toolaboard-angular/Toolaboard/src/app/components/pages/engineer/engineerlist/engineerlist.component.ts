import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engineerlist',
  templateUrl: './engineerlist.component.html',
  styleUrls: ['./engineerlist.component.css']
})
export class EngineerlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
