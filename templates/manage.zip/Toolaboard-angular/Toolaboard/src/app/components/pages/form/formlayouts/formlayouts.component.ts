import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formlayouts',
  templateUrl: './formlayouts.component.html',
  styleUrls: ['./formlayouts.component.css']
})
export class FormlayoutsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
