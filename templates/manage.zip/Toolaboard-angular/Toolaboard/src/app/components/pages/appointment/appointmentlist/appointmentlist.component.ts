import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointmentlist',
  templateUrl: './appointmentlist.component.html',
  styleUrls: ['./appointmentlist.component.css']
})
export class AppointmentlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
