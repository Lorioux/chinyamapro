import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addlabor',
  templateUrl: './addlabor.component.html',
  styleUrls: ['./addlabor.component.css']
})
export class AddlaborComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
