import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-schedulelist',
  templateUrl: './schedulelist.component.html',
  styleUrls: ['./schedulelist.component.css']
})
export class SchedulelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
