import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-webanalytics',
  templateUrl: './webanalytics.component.html',
  styleUrls: ['./webanalytics.component.css']
})
export class WebanalyticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
