import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adddepartment',
  templateUrl: './adddepartment.component.html',
  styleUrls: ['./adddepartment.component.css']
})
export class AdddepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
