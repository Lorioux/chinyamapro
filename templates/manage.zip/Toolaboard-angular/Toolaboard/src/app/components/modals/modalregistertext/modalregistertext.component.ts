import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modalregistertext',
  templateUrl: './modalregistertext.component.html',
  styleUrls: ['./modalregistertext.component.css']
})
export class ModalregistertextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
