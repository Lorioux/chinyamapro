import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modallogintext',
  templateUrl: './modallogintext.component.html',
  styleUrls: ['./modallogintext.component.css']
})
export class ModallogintextComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
